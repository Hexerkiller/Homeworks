
const div = document.querySelector('div')
div.innerHTML = "Это <em>курсивный</em> текст "